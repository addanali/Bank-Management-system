#include "securityquestiondialog.h"
#include "ui_securityquestiondialog.h"
#include <QMessageBox>
#include <QFile>
#include <QTextStream>
#include <adminauthenticationdialog.h>
#include <currentuser.h>
#include <currentuserloggedin.h>

SecurityQuestionDialog::SecurityQuestionDialog(const QString &username,QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::SecurityQuestionDialog)
    , forgotpin(username)
{
    ui->setupUi(this);
    this->setStyleSheet("QDialog { "
                        "background-image: url('C:/Users/Home/Pictures/background QT plain.png'); "
                        "background-repeat: no-repeat; "
                        "background-position: center; "
                        "background-size: cover; "
                        "}");
}

SecurityQuestionDialog::~SecurityQuestionDialog()
{
    delete ui;
}

void SecurityQuestionDialog::on_pushButtonSecQDisplay_clicked()
{

    QFile file("C:\\Users\\Home\\Documents\\BMSPROJ\\User Account Data\\" + forgotpin + ".txt");

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QMessageBox::warning(this, "Error", "Unable to open user data file.");
        return;
    }

    QTextStream in(&file);
    QString line;
    int lineCount = 0;

    while (!in.atEnd() && lineCount < 9)
    {
        line = in.readLine();
        lineCount++;
        if (lineCount == 9)
        {
            ui->lineEditSecQ->setText(line);
            break;
        }
    }

    file.close();
}


void SecurityQuestionDialog::on_pushButtonAdministrator_clicked()
{
    hide();
    AdminAuthenticationDialog thj;
    thj.setModal(true);
    thj.exec();
}


void SecurityQuestionDialog::on_pushButtonSecQBack_clicked()
{
    hide();
    CurrentUser vbn;
    vbn.setModal(true);
    vbn.exec();
}


void SecurityQuestionDialog::on_pushButtonSecQAuthenticate_clicked()
{

    QString inputAns = ui->lineEditSecQAns->text().trimmed();


    if (inputAns.isEmpty())
    {
        QMessageBox::warning(this, "Input Error", "Please enter answer.");
        return;
    }

    QFile file("C:\\Users\\Home\\Documents\\BMSPROJ\\User Account Data\\" + forgotpin + ".txt");

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QMessageBox::warning(this, "Error", "User not found.");
        return;
    }

    QTextStream in(&file);
    QString fileAns;
    int lineCount = 0;

    while (!in.atEnd() && lineCount < 10)
    {
        fileAns = in.readLine();
        lineCount++;
        if (lineCount == 10)
        {
            ui->lineEditSecQ->setText(fileAns);
            break;
        }
    }


    file.close();

    if (inputAns == fileAns)
    {
        QMessageBox::information(this, "User Identified", "Welcome, " + forgotpin);

        hide();
        CurrentUserLoggedIn lmo;
        lmo.setUsername(forgotpin);
        lmo.setModal(true);
        lmo.exec();

        return;

    }

    else
    {

        QMessageBox::warning(this, "Authentication Failed", "Incorrect answer for the provided username.");
    }
}

