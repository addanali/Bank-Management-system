#ifndef SECURITYQUESTIONDIALOG_H
#define SECURITYQUESTIONDIALOG_H

#include <QDialog>

namespace Ui {
class SecurityQuestionDialog;
}

class SecurityQuestionDialog : public QDialog
{
    Q_OBJECT

public:
    explicit SecurityQuestionDialog(const QString &username,QWidget *parent = nullptr);
    ~SecurityQuestionDialog();

private slots:
    void on_pushButtonSecQDisplay_clicked();

    void on_pushButtonAdministrator_clicked();

    void on_pushButtonSecQBack_clicked();

    void on_pushButtonSecQAuthenticate_clicked();

private:
    Ui::SecurityQuestionDialog *ui;
    QString forgotpin;
};

#endif // SECURITYQUESTIONDIALOG_H
